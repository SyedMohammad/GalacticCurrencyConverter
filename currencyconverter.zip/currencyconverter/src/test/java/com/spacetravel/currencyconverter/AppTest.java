package com.spacetravel.currencyconverter;

import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;

import bean.ConversionResultBean;
import filter.FilterSymbol;
import rule.engine.RuleEngineImpl;

/**
 * Unit test for simple App.
 */
public class AppTest {
	
		/* Test Scenario:
		 * Filter Roman Numeral Strings from Complete Input Line
		 * Ex: Filter "MMVI" from complete string "glob blob MMVI"
		 */
	    @Test		
	    public void RomanFilterTest(){					
	        	
	    	List<String> inputList = new ArrayList<String>();
	    	inputList.add("glob glob MMVI");
	    	
	        FilterSymbol filterTest = new FilterSymbol(inputList);
	        List<String> romanNumeral = filterTest.FilterRomanNumeral();
	        
	        assertEquals("MMVI", romanNumeral.get(0));
	    }
	    
	    /* Test Scenario:
	     * Filter Arabic Numeral Expression from Complete Input Line
		 * Ex: Filter "57800" from complete string "bolb blob gold is 57800 credits"
		 */
	    @Test		
	    public void ArabicFilterTest(){					
	        	
	    	List<String> inputList = new ArrayList<String>();
	    	inputList.add("glob glob Sliver is Gold 57800");
	    	
	        FilterSymbol filterTest = new FilterSymbol(inputList);
	        List<String> arabicNumeral = filterTest.FilterArabicNumeral();
	        
	        assertEquals("57800", arabicNumeral.get(0));
	    }
	    
	    /* Test Scenario:
		 * Rule 1: Only 3 Consecutive Repetitions Allowed for I,X,C,M
		 */
	    @Test
	    public void ValidateRuleOne()
	    {
	    	List<String> romanNumeral = new ArrayList<String>();
	    	romanNumeral.add("MMCCCC");
	    	RuleEngineImpl ruleImpl = new RuleEngineImpl();
	    	ruleImpl.setRomanNumeral(romanNumeral);
	    	
	    	List<String> result = ruleImpl.CheckRuleOne();
	    	assertEquals("invalid input currency - i,x,c or m is repeated more than 3 times in the string.", result.get(0));
	    }
	    
	    /* Test Scenario:
		 * Rule 2: No Repetition for D,L,V Allowed
		 */
	    @Test
	    public void ValidateRuleTwo()
	    {
	    	List<String> romanNumeral = new ArrayList<String>();
	    	romanNumeral.add("MMDD");
	    	RuleEngineImpl ruleImpl = new RuleEngineImpl();
	    	ruleImpl.setRomanNumeral(romanNumeral);
	    	
	    	List<String> result = ruleImpl.CheckRuleTwo();
	    	assertEquals("invalid input currency - no repetition for d,l or v is allowed.", result.get(0));
	    }
	    
	    /* Test Scenario:
		 * Roman Currency Conversion to Galactic
		 * Ex : MMVI = 2006 & MCMXLIV = 1944
		 */
	    @Test
	    public void TestRomanCurrencyConversion()
	    {
	    	List<String> romanNumeral = new ArrayList<String>();
	    	romanNumeral.add("MMVI");
	    	romanNumeral.add("MCMXLIV");
	    	
	    	List<ConversionResultBean> result = new ArrayList<ConversionResultBean>();
			CurrencyConverterImpl currConverter = new CurrencyConverterImpl();
			result = currConverter.RomanToGalacticCurrencyConvereter(romanNumeral);
			
			assertEquals(2006, result.get(0).getValue());
			assertEquals(1944, result.get(1).getValue());
	    }
	    
	
}
