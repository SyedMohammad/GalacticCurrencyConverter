package rule.engine;

import java.util.HashMap;
import java.util.List;

import com.spacetravel.currencyconverter.RomanNumeralConstant;

public class RuleEngineImpl implements RuleEngine{
	
	private List<String> romanNumeral;

	public List<String> getRomanNumeral() {
		return romanNumeral;
	}

	public void setRomanNumeral(List<String> romanNumeral) {
		this.romanNumeral = romanNumeral;
	}

	@Override
	public List<String> CheckRuleOne() {

		int listIndex = 0;

		for (String romanExpression : romanNumeral) {
			HashMap<Character, Integer> charsFound = CommonRuleMap(romanExpression);

			for (Character ch : charsFound.keySet()) {

				if (ch == RomanNumeralConstant.I.getRomanSymbol() || ch == RomanNumeralConstant.X.getRomanSymbol()
						|| ch == RomanNumeralConstant.C.getRomanSymbol()
						|| ch == RomanNumeralConstant.M.getRomanSymbol() && charsFound.get(ch) > 3) {
					romanNumeral.set(listIndex,
							"invalid input currency - i,x,c or m is repeated more than 3 times in the string.");
				}
			}
			listIndex++;
		}
		return romanNumeral;
	}

	@Override
	public List<String> CheckRuleTwo() {
		
		int listIndex = 0;
		for (String romanExpression : romanNumeral) {
			HashMap<Character, Integer> charsFound = CommonRuleMap(romanExpression);

			for (Character ch : charsFound.keySet()) {

				if (ch == RomanNumeralConstant.D.getRomanSymbol() || ch == RomanNumeralConstant.I.getRomanSymbol()
						|| ch == RomanNumeralConstant.V.getRomanSymbol() && charsFound.get(ch) > 1) {
					romanNumeral.set(listIndex, "invalid input currency - no repetition for d,l or v is allowed.");
				}
			}

			listIndex++;
		}

		return romanNumeral;
	}

	@Override
	public HashMap<Character, Integer> CommonRuleMap(String romanNumeral) {


		char s[] = romanNumeral.toCharArray();
		HashMap<Character, Integer> charsFound = new HashMap<>();

		if (s.length > 0) {
			int count = 1;
			char c = s[0];
			for (int i = 1; i < s.length; i++) {
				if (c == s[i] && count >= 1 && s.length - 1 == i) {
					if (!charsFound.containsKey(c))
						charsFound.put(c, ++count);
					else if (charsFound.get(c) < ++count)
						charsFound.put(c, count);
				} else if (c == s[i]) {
					count++;
				} else {
					if (count > 1) {
						if (!charsFound.containsKey(c))
							charsFound.put(c, count);
						else if (charsFound.get(c) < count)
							charsFound.put(c, count);
					}
					c = s[i];
					count = 1;
				}
			}
		}

		return charsFound;
	
	}

}
