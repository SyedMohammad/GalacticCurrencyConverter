package rule.engine;

import java.util.HashMap;
import java.util.List;

public interface RuleEngine {
	
	List<String> CheckRuleOne();
	List<String> CheckRuleTwo();
	HashMap<Character, Integer> CommonRuleMap(String romanNumeral);

}
