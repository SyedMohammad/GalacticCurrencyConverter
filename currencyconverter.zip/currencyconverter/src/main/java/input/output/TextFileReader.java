package input.output;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

public class TextFileReader {
	
	final static Logger logger = Logger.getLogger(TextFileReader.class);
	
	public List<String> InputFileReader(String inputFilePath)
	{
		List<String> result = new ArrayList<String>();

		try {

			result = Files.readAllLines(Paths.get(inputFilePath));

		} catch (IOException e) {
			
			logger.error(e);
		}
		
		return result;
		
	}

}
