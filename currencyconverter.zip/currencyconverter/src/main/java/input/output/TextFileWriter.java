package input.output;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.List;

import org.apache.log4j.Logger;

import bean.ConversionResultBean;

public class TextFileWriter {

	final static Logger logger = Logger.getLogger(TextFileReader.class);
	
	private List<ConversionResultBean> result;
	private String fileContent;

	public List<ConversionResultBean> getResult() {
		return result;
	}

	public void setResult(List<ConversionResultBean> result) {
		this.result = result;
	}

	public void FileWriter() {
		
		fileContent = ResultFormatter(this.result);

		try (FileWriter writer = new FileWriter("result/Result.txt"); BufferedWriter bw = new BufferedWriter(writer)) {

			bw.write(fileContent);

		} catch (IOException e) {
			
			logger.error(e);
		}
	}

	private String ResultFormatter(List<ConversionResultBean> result2) {
		
		StringBuffer sb = new StringBuffer();
		
		for(ConversionResultBean bean : result2)
		{
			sb.append("Roman Expression \""+ bean.getExpression() +"\" is Equivalent to \""+ bean.getValue() +"\" Galactic Exchange.");
			sb.append("\n");
		}
		return sb.toString();
	}
	
	

}
