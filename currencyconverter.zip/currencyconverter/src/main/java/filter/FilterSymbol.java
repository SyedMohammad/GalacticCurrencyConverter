package filter;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class FilterSymbol {

	private List<String> inputList;

	public FilterSymbol(List<String> inputList) {

		this.inputList = inputList;
	}

	public List<String> FilterRomanNumeral() {
		
		List<String> romanNumeralList = new ArrayList<String>();

		for (String line : inputList) {
			String romanNumerals = line.chars().filter(Character::isUpperCase)
					.mapToObj(c -> Character.toString((char) c)).collect(Collectors.joining());
			romanNumeralList.add(romanNumerals);
		}

		return romanNumeralList;
	}
	
	public List<String> FilterArabicNumeral() {
		List<String> arabicNumeralList = new ArrayList<String>();

		for (String line : inputList) {
			String numberOnly = line.replaceAll("[^0-9]", "");
			arabicNumeralList.add(numberOnly);
		}

		return arabicNumeralList;
	}

}
