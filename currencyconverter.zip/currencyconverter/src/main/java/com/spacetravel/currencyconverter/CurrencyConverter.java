package com.spacetravel.currencyconverter;

import java.util.List;

import bean.ConversionResultBean;

public interface CurrencyConverter {
	
		List<ConversionResultBean> RomanToGalacticCurrencyConvereter(List<String> romanNumeral);
		List<ConversionResultBean> ArabicToRomanCurrencyConvereter(List<String> arabicNumeral);

}
