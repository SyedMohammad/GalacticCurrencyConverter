package com.spacetravel.currencyconverter;

import java.util.ArrayList;
import java.util.List;

import bean.ConversionResultBean;

public class CurrencyConverterImpl implements CurrencyConverter{

	@Override
	public List<ConversionResultBean> RomanToGalacticCurrencyConvereter(List<String> romanNumeral) {

		List<ConversionResultBean> result = new ArrayList<ConversionResultBean>();

		for (String romanString : romanNumeral) {
			
			ConversionResultBean resultBean = new ConversionResultBean();
			int galacticResult = 0;

			if (romanString.length() > 0) {
				char romanSymbol = romanString.charAt(0);
				int romanValue = 0;

				for (RomanNumeralConstant rNum : RomanNumeralConstant.values()) {
					if (romanSymbol == rNum.getRomanSymbol()) {
						romanValue = rNum.getRomanValue();
					}
				}

				galacticResult = RecurssiveFunction(romanValue, romanString.substring(1));
			}
			
			resultBean.setExpression(romanString);
			resultBean.setValue(galacticResult);
			
			result.add(resultBean);
		}
		
		return result;
	
	}

	@Override
	public List<ConversionResultBean> ArabicToRomanCurrencyConvereter(List<String> arabicNumeral) {
		// TODO Auto-generated method stub
		return null;
	}
	
	private static int RecurssiveFunction(int preRomanValue, String romanString) {

		if (romanString.length() == 0) {
			return preRomanValue;
		}

		for (int i = 0, n = romanString.length(); i < n; i++) {
			char romanSymbol = romanString.charAt(i);
			int currRomanValue = 0;

			for (RomanNumeralConstant rNum : RomanNumeralConstant.values()) {
				if (romanSymbol == rNum.getRomanSymbol()) {
					currRomanValue = rNum.getRomanValue();
				}
			}

			if (preRomanValue >= currRomanValue) {
				return preRomanValue + RecurssiveFunction(currRomanValue, romanString.substring(i + 1));
			} else if (currRomanValue > preRomanValue) {
				return RecurssiveFunction(currRomanValue, romanString.substring(i + 1)) - preRomanValue;
			}

		}

		return 0;
	}

}
