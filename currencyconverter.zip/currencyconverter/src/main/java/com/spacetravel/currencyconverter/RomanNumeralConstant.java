package com.spacetravel.currencyconverter;

public enum RomanNumeralConstant {

	I('I',1),
	V('V',5),
	X('X',10),
	L('L',50),
	C('C',100),
	D('D',500),
	M('M',1000);
	
	private int romanValue;
	private char romanSymbol;
	
	RomanNumeralConstant(char romanSymbol, int numericValue)
	{
		this.romanSymbol = romanSymbol;
		this.romanValue = numericValue;
	}
	
	public char getRomanSymbol() {
		return romanSymbol;
	}

	public int getRomanValue() {
		return romanValue;
	}
	
}
