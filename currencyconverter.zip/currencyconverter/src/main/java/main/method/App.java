package main.method;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.apache.log4j.Logger;

import com.spacetravel.currencyconverter.CurrencyConverterImpl;

import bean.ConversionResultBean;
import filter.FilterSymbol;
import input.output.TextFileReader;
import input.output.TextFileWriter;
import rule.engine.RuleEngineImpl;

/**
 * The Merchants Guide to Galaxy
 */
public class App {
	
	final static Logger logger = Logger.getLogger(App.class);

	public static void main(String[] args) {
		
		/* Input File Path in Project Directory */
		String inputFilePath = "resources/InputFile.txt";
		
		/* Read Txt File as Input */
		TextFileReader input = new TextFileReader();
		List<String> inputList = input.InputFileReader(inputFilePath);
		
		/* Filter Roman Numeral Strings from Complete Input Line
		 * Ex: Filter "MMVI" from complete string "glob blob MMVI"
		 */
		FilterSymbol filter = new FilterSymbol(inputList);
		List<String> romanNumeral = filter.FilterRomanNumeral();
		
		/* Filter Arabic Numeral Expression from Complete Input Line
		 * Ex: Filter "57800" from complete string "bolb blob gold is 57800 credits"
		 */
		List<String> arabicNumeral = filter.FilterArabicNumeral();

		/* Convert Arabic Numeral Expression to Equivalent Roman Numeral Expression
		 * Ex: 1903 = MCMIII
		 */
		romanNumeral = ArabicToRomanNumeralConversion(arabicNumeral, romanNumeral);
		
		
		RuleEngineImpl ruleEngine = new RuleEngineImpl();
		ruleEngine.setRomanNumeral(romanNumeral);
		/*
		 * Rule 1: Only 3 Consecutive Repetitions Allowed for I,X,C,M
		 */
		romanNumeral = ruleEngine.CheckRuleOne();

		/*
		 * Rule 2: No Repetition for D,L,V Allowed
		 */
		romanNumeral = ruleEngine.CheckRuleTwo();

		/* Roman Currency Conversion to Galactic
		 * Ex : MMVI = 2006
		 */
		List<ConversionResultBean> result = new ArrayList<ConversionResultBean>();
		TextFileWriter fileWriter = new TextFileWriter();
		CurrencyConverterImpl currConverter = new CurrencyConverterImpl();
		result = currConverter.RomanToGalacticCurrencyConvereter(romanNumeral);
		fileWriter.setResult(result);
		fileWriter.FileWriter();

	}

	private static List<String> ArabicToRomanNumeralConversion(List<String> arabicNumeral, List<String> romanNumeral) {

		for (String number : arabicNumeral) {
			
			int num = 0;
			
			try
			{
				num = Integer.parseInt(number);
			}
			catch(NumberFormatException e)
			{
				logger.error(e);
			}

			List<Integer> eachDigit = Digits(num);

			for (int i = 0; i < eachDigit.size(); i++) {
				
			}
		}
		return romanNumeral;
	}

	private static List<Integer> Digits(int num) {

		List<Integer> digits = new ArrayList<Integer>();

		while (num > 0) {
			digits.add(num % 10);
			num /= 10;
		}
		return digits;

	}
}
